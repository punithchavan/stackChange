const express = require('express');
const router = express.Router();
const Post = require('../models/Post');
const User = require('../models/User');
const Comment = require('../models/Comment');

router.post('/add_comment', async (req, res) => {
const { post_id, user_id, comment_text } = req.body;
try {
const post = await Post.findById(post_id);
const user = await User.findById(user_id);
if (!post || !user) {
return res.status(400).json({ error: 'Invalid post or user' });
}
const comment = await Comment.create({ post, user, comment_text });
res.json({ message: 'Comment added', comment_id: comment._id });
} catch (error) {
res.status(400).json({ error: 'Invalid post or user' });
}
});


module.exports = router;